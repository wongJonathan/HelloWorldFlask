from clickclick.console import *  # noqa

__version__ = '1.2.1'
